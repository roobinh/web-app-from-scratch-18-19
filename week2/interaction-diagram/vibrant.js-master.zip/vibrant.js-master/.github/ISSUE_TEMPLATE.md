# ⚠️ THIS REPO IS DEPRECATED ⚠️

Vibrant.js is deprecated. This repo is kept solely for historical reasons. Ongoing development will happen over [node-vibrant].

Despite node-vibrant's name, it works with both node and the browser (with and without UMD support).
**It is highly recommended you use that project over this one.**

Do NOT submit your issue here. Please:
1. Try reproducing your problem with [node-vibrant]
2. If it persists, submit an issue there.

[node-vibrant]: https://github.com/akfish/node-vibrant